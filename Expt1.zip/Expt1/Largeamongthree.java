import java.util.Scanner;
class Largeamongthree
{

    public static void main(String args[]) 
    {

        int a,b,c;
        Scanner r = new Scanner(System.in);
        System.out.println("enter the first number:");
        a=r.nextInt();
        System.out.println("enter the second number:");
        b=r.nextInt();
        System.out.println("enter the third number:");
        c=r.nextInt();

        if( a>=b && a>=c)
            System.out.println("largest number is:"+a);

        else if (b>=a && b>=c)
            System.out.println("largest number is:"+b);

        else
            System.out.println("largest number is:"+c);
    }
}