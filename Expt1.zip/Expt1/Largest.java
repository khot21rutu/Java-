/*import java.util.Scanner;
class Largest 
{
	public static void main(String args[]) 
	{
		int a, b;
		Scanner r = new Scanner(System.in);
		
		System.out.print(" Please Enter the First Number: ");
		a = r.nextInt();	
		
		System.out.print(" Please Enter the Second Number: ");
		b = r.nextInt();	
		
		if(a > b) 
	    {
			System.out.println("The Largest Number = "+ a);          
	    } 
	    else if (b > a)
	    { 
	    	System.out.println("The Largest Number = "+ b);        
	    } 
	    else 
	    {
	    	System.out.println("Both are Equal");
	    }		
	}	
}*/


import java.util.Scanner;
class Largest
{
	public static void main(String args[])
	{
		int a,b,max;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 1st no.:");
		a=sc.nextInt();
		System.out.println("enter 2nd no.:");
		b=sc.nextInt();
		max=(a>b)?a:b;
		System.out.println("max is:"+max);
	}
}




















