import java.util.Scanner;
class Addition
{
	public static void main(String args[])
	{
	int a,b,c;
	System.out.print("enter the two numbers:");
	Scanner s=new Scanner(System.in);
	a=s.nextInt();
	b=s.nextInt();	
	c=a+b;
	System.out.print("addition is:"+c);
	}
}