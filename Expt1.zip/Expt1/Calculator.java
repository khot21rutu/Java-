import java.util.Scanner;

class Calculator 
{
  public static void main(String args[]) 
  {

    int a,b,c,ch=0;

    Scanner s = new Scanner(System.in);
    while(ch!=4)
    {

    System.out.println("1.addition \n2.substraction \n3.multiplication \n4.division\n5.exit");
    System.out.println("Choose your choice");
    ch = s.nextInt();

    System.out.println("Enter first number");
    a = s.nextInt();

    System.out.println("Enter second number");
    b = s.nextInt();

    switch (ch) 
    {
      case 1:
        c = a + b;
        System.out.println(a + " + " + b + " = " + c);
        break;

      case 2:
        c = a - b;
        System.out.println(a + " - " + b + " = " + c);
        break;

      case 3:
        c = a * b;
        System.out.println(a + " * " + b + " = " + c);
        break;

      case 4:
        c = a / b;
        System.out.println(a + " / " + b + " = " + c);
        break;
 
      default:
        System.out.println("Invalid choice..!!");
      
    }
  }
  }
}