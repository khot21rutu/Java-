// import java.util.Scanner;
// class Factorial
// {
// 	public static void main(String args[])
// 	{
// 	int a,i,fact=1;
// 	System.out.print("enter the number:");
// 	Scanner r=new Scanner(System.in);
// 	a=r.nextInt();
// 	for(i=1;i<=a;i++)
// 	{
// 		fact=fact*i;
// 	}
// 	System.out.println("Factorial of number is: "+fact);
// 	}
// }



class Factorial
{
	public static void main(String args[])
	{
		int i,fact=1;
		int a=Integer.parseInt(args[0]);
		for(i=1;i<=a;i++)
		{
			fact=fact*i;
		}
		System.out.println("factorial is:"+fact);
	}

}
