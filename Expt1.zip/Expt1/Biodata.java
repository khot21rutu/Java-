class Biodata
{
	public static void main(String args[])
	{
     System.out.println("Name:RUTUJA RAJARAM KHOT.");
     System.out.println("Class:T.Y.BTech");
     System.out.println("Branch:CS&IT");
     System.out.println("PRN No.:2010064");
     System.out.println("Collage:RIT,Islampur");

	}
}